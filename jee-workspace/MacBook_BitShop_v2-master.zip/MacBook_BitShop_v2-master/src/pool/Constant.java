package pool;

public class Constant {
	public static final String VIEW = "WEB-INF/view/";
	public static final String JSP = ".jsp";
	public static final String MAIN = "main";
	public static final String ORACLE_DRIVER = "oracle.jdbc.OracleDriver";
	public static final String ORACLE_URL = "jdbc:oracle:thin:@localhost:59162:xe";
	public static final String USERNAME = "oracle";
	public static final String PASSWORD = "password";
	public static final String VENDOR = "ORACLE";
	
	
	
}
          